package com.royalcardclash.game.engine

import com.royalcardclash.game.model.BattleResult
import com.royalcardclash.game.model.GamePhase
import com.royalcardclash.game.model.PlayingCardModel
import com.royalcardclash.game.model.Rank
import com.royalcardclash.game.model.Suit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class GameState(
    val playerDeck: List<PlayingCardModel> = emptyList(),
    val aiDeck: List<PlayingCardModel> = emptyList(),
    val playerWonCards: List<PlayingCardModel> = emptyList(),
    val aiWonCards: List<PlayingCardModel> = emptyList(),
    val currentBattlePlayerCard: PlayingCardModel? = null,
    val currentBattleAiCard: PlayingCardModel? = null,
    val warPile: List<PlayingCardModel> = emptyList(),
    val playerScore: Int = 26,
    val aiScore: Int = 26,
    val roundsPlayed: Int = 0,
    val phase: GamePhase = GamePhase.IDLE,
    val lastBattleResult: BattleResult? = null,
    val statusMessage: String = "Tap 'BATTLE' to start the duel!",
    val isWarActive: Boolean = false,
    val isPaused: Boolean = false
)

class GameEngine {

    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    fun startNewGame() {
        val fullDeck = createFairShuffledDeck()
        val pDeck = fullDeck.take(26)
        val aDeck = fullDeck.drop(26)

        _gameState.value = GameState(
            playerDeck = pDeck,
            aiDeck = aDeck,
            playerScore = 26,
            aiScore = 26,
            phase = GamePhase.READY_TO_BATTLE,
            statusMessage = "Match started! Tap 'BATTLE' to draw cards."
        )
    }

    private fun createFairShuffledDeck(): List<PlayingCardModel> {
        val cards = buildList {
            for (suit in Suit.entries) {
                for (rank in Rank.entries) {
                    add(PlayingCardModel(suit = suit, rank = rank))
                }
            }
        }
        return cards.shuffled()
    }

    fun playBattleRound(): Pair<BattleResult, Int> {
        val state = _gameState.value
        if (state.phase == GamePhase.GAME_OVER || state.isPaused) {
            return Pair(state.lastBattleResult ?: BattleResult.WAR_TIE, 0)
        }

        var pDeck = state.playerDeck.toMutableList()
        var aDeck = state.aiDeck.toMutableList()
        val pWon = state.playerWonCards.toMutableList()
        val aWon = state.aiWonCards.toMutableList()
        val currentWarPile = state.warPile.toMutableList()

        // Captured piles become the player's reusable deck when the draw pile is empty.
        replenishIfNeeded(pDeck, pWon)
        replenishIfNeeded(aDeck, aWon)

        if (pDeck.isEmpty()) {
            finishGame(playerWon = false, message = "AI captured all cards!")
            return Pair(BattleResult.AI_WIN, currentWarPile.size)
        }
        if (aDeck.isEmpty()) {
            finishGame(playerWon = true, message = "You captured all cards!")
            return Pair(BattleResult.PLAYER_WIN, currentWarPile.size)
        }

        val playerCard = pDeck.removeAt(0).copy(isFaceUp = true)
        val aiCard = aDeck.removeAt(0).copy(isFaceUp = true)
        currentWarPile += playerCard
        currentWarPile += aiCard

        val result = when {
            playerCard.rank.value > aiCard.rank.value -> BattleResult.PLAYER_WIN
            aiCard.rank.value > playerCard.rank.value -> BattleResult.AI_WIN
            else -> BattleResult.WAR_TIE
        }

        if (result == BattleResult.WAR_TIE) {
            // A complete War requires 3 face-down cards AND 1 next face-up card.
            // If either player cannot supply all 4 cards, that player loses.
            replenishIfNeeded(pDeck, pWon)
            replenishIfNeeded(aDeck, aWon)

            if (pDeck.size < 4) {
                finishGame(
                    playerWon = false,
                    message = "You cannot complete the War. AI wins!"
                )
                return Pair(BattleResult.AI_WIN, currentWarPile.size)
            }
            if (aDeck.size < 4) {
                finishGame(
                    playerWon = true,
                    message = "AI cannot complete the War. You win!"
                )
                return Pair(BattleResult.PLAYER_WIN, currentWarPile.size)
            }

            repeat(3) {
                currentWarPile += pDeck.removeAt(0).copy(isFaceUp = false)
                currentWarPile += aDeck.removeAt(0).copy(isFaceUp = false)
            }

            val playerScore = pDeck.size + pWon.size
            val aiScore = aDeck.size + aWon.size

            _gameState.update {
                it.copy(
                    playerDeck = pDeck,
                    aiDeck = aDeck,
                    playerWonCards = pWon,
                    aiWonCards = aWon,
                    currentBattlePlayerCard = playerCard,
                    currentBattleAiCard = aiCard,
                    warPile = currentWarPile,
                    playerScore = playerScore,
                    aiScore = aiScore,
                    roundsPlayed = state.roundsPlayed + 1,
                    phase = GamePhase.WAR_DECLARED,
                    lastBattleResult = BattleResult.WAR_TIE,
                    statusMessage = "⚔️ WAR DECLARED! 3 cards down — now reveal the War card!",
                    isWarActive = true
                )
            }

            return Pair(BattleResult.WAR_TIE, currentWarPile.size)
        }

        // Non-tie: winner captures the complete battle/war pile.
        val cardsWon = currentWarPile.size
        if (result == BattleResult.PLAYER_WIN) {
            pWon.addAll(currentWarPile)
        } else {
            aWon.addAll(currentWarPile)
        }

        val playerScore = pDeck.size + pWon.size
        val aiScore = aDeck.size + aWon.size
        val isGameOver = playerScore == 52 || aiScore == 52

        if (isGameOver) {
            finishGame(
                playerWon = playerScore == 52,
                message = if (playerScore == 52) {
                    "VICTORY! You captured all 52 cards!"
                } else {
                    "DEFEAT! AI captured all 52 cards!"
                },
                playerDeck = pDeck,
                aiDeck = aDeck,
                playerWonCards = pWon,
                aiWonCards = aWon,
                roundsPlayed = state.roundsPlayed + 1,
                playerScore = playerScore,
                aiScore = aiScore,
                warPile = emptyList(),
                lastResult = result
            )
        } else {
            _gameState.update {
                it.copy(
                    playerDeck = pDeck,
                    aiDeck = aDeck,
                    playerWonCards = pWon,
                    aiWonCards = aWon,
                    currentBattlePlayerCard = playerCard,
                    currentBattleAiCard = aiCard,
                    warPile = emptyList(),
                    playerScore = playerScore,
                    aiScore = aiScore,
                    roundsPlayed = state.roundsPlayed + 1,
                    phase = GamePhase.READY_TO_BATTLE,
                    lastBattleResult = result,
                    statusMessage = if (result == BattleResult.PLAYER_WIN) {
                        "Round Won! You captured $cardsWon cards."
                    } else {
                        "AI won the round and captured $cardsWon cards."
                    },
                    isWarActive = false
                )
            }
        }

        return Pair(result, cardsWon)
    }

    private fun replenishIfNeeded(
        deck: MutableList<PlayingCardModel>,
        wonPile: MutableList<PlayingCardModel>
    ) {
        if (deck.isEmpty() && wonPile.isNotEmpty()) {
            deck.addAll(wonPile.shuffled().map { it.copy(isFaceUp = false) })
            wonPile.clear()
        }
    }

    private fun finishGame(
        playerWon: Boolean,
        message: String,
        playerDeck: MutableList<PlayingCardModel> = _gameState.value.playerDeck.toMutableList(),
        aiDeck: MutableList<PlayingCardModel> = _gameState.value.aiDeck.toMutableList(),
        playerWonCards: MutableList<PlayingCardModel> = _gameState.value.playerWonCards.toMutableList(),
        aiWonCards: MutableList<PlayingCardModel> = _gameState.value.aiWonCards.toMutableList(),
        roundsPlayed: Int = _gameState.value.roundsPlayed,
        playerScore: Int = if (playerWon) 52 else 0,
        aiScore: Int = if (playerWon) 0 else 52,
        warPile: List<PlayingCardModel> = emptyList(),
        lastResult: BattleResult? = if (playerWon) BattleResult.PLAYER_WIN else BattleResult.AI_WIN
    ) {
        _gameState.update {
            it.copy(
                playerDeck = playerDeck,
                aiDeck = aiDeck,
                playerWonCards = playerWonCards,
                aiWonCards = aiWonCards,
                playerScore = playerScore,
                aiScore = aiScore,
                roundsPlayed = roundsPlayed,
                warPile = warPile,
                phase = GamePhase.GAME_OVER,
                lastBattleResult = lastResult,
                statusMessage = message,
                isWarActive = false
            )
        }
    }

    fun togglePause(isPaused: Boolean) {
        _gameState.update { it.copy(isPaused = isPaused) }
    }
}
