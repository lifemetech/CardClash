package com.royalcardclash.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.royalcardclash.game.model.GamePhase
import com.royalcardclash.game.model.PlayingCardModel
import com.royalcardclash.game.model.Rank
import com.royalcardclash.game.model.StrategyTool
import com.royalcardclash.game.model.Suit
import com.royalcardclash.game.ui.components.PlayingCardView
import com.royalcardclash.game.viewmodel.GameViewModel

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    onBackToHome: () -> Unit
) {
    val state by viewModel.gameState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF071E1A), Color(0xFF020B0A))
                )
            )
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0B3D34), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFFFD54F), RoundedCornerShape(16.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Score("AI", state.aiScore, Color(0xFFFF8A9B))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "ROUND ${state.roundsPlayed}",
                        color = Color(0xFFFFD54F),
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "ENERGY ${state.energy}/${state.maxEnergy}",
                        color = Color(0xFF7DD3FC),
                        fontSize = 11.sp
                    )
                }
                Score("YOU", state.playerScore, Color(0xFF6EE7B7))
                IconButton(onClick = { viewModel.setPauseState(true) }) {
                    Icon(Icons.Default.Pause, contentDescription = "Pause", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AI DECK", color = Color.LightGray, fontSize = 11.sp)
                    PlayingCardView(
                        card = PlayingCardModel(suit = Suit.SPADES, rank = Rank.ACE),
                        modifier = Modifier.size(width = 52.dp, height = 76.dp)
                    )
                }
                Text("VS", color = Color(0xFFFFD54F), fontWeight = FontWeight.Black)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("YOUR DECK", color = Color.LightGray, fontSize = 11.sp)
                    PlayingCardView(
                        card = PlayingCardModel(suit = Suit.HEARTS, rank = Rank.ACE),
                        modifier = Modifier.size(width = 52.dp, height = 76.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A4F43)),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "STRATEGY TABLE",
                            color = Color(0xFFFFD54F),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            state.statusMessage,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(vertical = 7.dp)
                        )
                    }

                    if (state.previewCard != null && state.phase == GamePhase.READY_TO_BATTLE) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("SCOUTED NEXT CARD", color = Color(0xFF7DD3FC), fontSize = 10.sp)
                            PlayingCardView(
                                card = state.previewCard!!,
                                modifier = Modifier.size(width = 60.dp, height = 86.dp)
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        state.currentBattlePlayerCard?.let { card ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("YOU", color = Color.LightGray, fontSize = 10.sp)
                                PlayingCardView(
                                    card = card,
                                    modifier = Modifier.size(width = 72.dp, height = 104.dp)
                                )
                            }
                        }

                        if (state.currentBattlePlayerCard != null && state.currentBattleAiCard != null) {
                            Text(
                                if (state.isWarActive) "⚔️ WAR" else "VS",
                                color = Color(0xFFFFD54F),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        state.currentBattleAiCard?.let { card ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("AI", color = Color.LightGray, fontSize = 10.sp)
                                PlayingCardView(
                                    card = card,
                                    modifier = Modifier.size(width = 72.dp, height = 104.dp)
                                )
                            }
                        }
                    }

                    if (state.isWarActive) {
                        Text(
                            "Battle pile: ${state.warPile.size} cards",
                            color = Color(0xFFFFD54F),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("YOUR TOOLS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ToolButton(
                    title = "👁 SCOUT",
                    count = "${state.scoutCharges}",
                    color = Color(0xFF2563EB),
                    enabled = state.energy >= 1 && state.scoutCharges > 0 && !state.isWarActive,
                    onClick = { viewModel.useTool(StrategyTool.SCOUT) }
                )
                ToolButton(
                    title = "⚡ POWER",
                    count = "${state.powerCharges}",
                    color = Color(0xFFD97706),
                    enabled = state.energy >= 2 && state.powerCharges > 0 && !state.isWarActive,
                    onClick = { viewModel.useTool(StrategyTool.POWER) }
                )
                ToolButton(
                    title = "🛡 SHIELD",
                    count = "${state.shieldCharges}",
                    color = Color(0xFF059669),
                    enabled = state.energy >= 2 && state.shieldCharges > 0 && !state.isWarActive,
                    onClick = { viewModel.useTool(StrategyTool.SHIELD) }
                )
                ToolButton(
                    title = "🔄 SWAP",
                    count = "${state.swapCharges}",
                    color = Color(0xFF7C3AED),
                    enabled = state.energy >= 3 && state.swapCharges > 0 && !state.isWarActive,
                    onClick = { viewModel.useTool(StrategyTool.SWAP) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = { viewModel.executeBattleRound() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                enabled = state.phase != GamePhase.GAME_OVER,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.isWarActive) Color(0xFFE11D48) else Color(0xFFF59E0B)
                ),
                shape = RoundedCornerShape(27.dp)
            ) {
                Text(
                    if (state.isWarActive) "⚔️ FIGHT WAR" else "🃏 BATTLE NOW",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Cards remaining: You ${state.playerScore} • AI ${state.aiScore}",
                color = Color.LightGray,
                fontSize = 11.sp
            )
        }

        if (state.isPaused) {
            OverlayPause(viewModel, onBackToHome)
        }
        if (state.phase == GamePhase.GAME_OVER) {
            OverlayResult(state, onBackToHome) { viewModel.startNewGame() }
        }
    }
}

@Composable
private fun Score(label: String, value: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color.LightGray, fontSize = 11.sp)
        Text("$value", color = color, fontWeight = FontWeight.Black, fontSize = 20.sp)
    }
}

@Composable
private fun ToolButton(
    title: String,
    count: String,
    color: Color,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .weight(1f)
            .height(58.dp),
        enabled = enabled,
        contentPadding = PaddingValues(2.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            disabledContainerColor = Color(0xFF334155)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("$count left", fontSize = 9.sp)
        }
    }
}

@Composable
private fun OverlayPause(vm: GameViewModel, back: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.82f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.86f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("GAME PAUSED", color = Color(0xFFFFD54F), fontWeight = FontWeight.Black, fontSize = 24.sp)
                Button(onClick = { vm.setPauseState(false) }, modifier = Modifier.fillMaxWidth()) {
                    Text("RESUME")
                }
                Button(
                    onClick = { vm.setPauseState(false); back() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151))
                ) {
                    Text("MAIN MENU")
                }
            }
        }
    }
}

@Composable
private fun OverlayResult(
    state: com.royalcardclash.game.engine.GameState,
    back: () -> Unit,
    replay: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.86f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.88f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val win = state.playerScore > state.aiScore
                Text(
                    if (win) "🏆 VICTORY" else "DEFEAT",
                    color = if (win) Color(0xFFFFD54F) else Color(0xFFFB7185),
                    fontWeight = FontWeight.Black,
                    fontSize = 30.sp
                )
                Text(
                    "You ${state.playerScore}  •  AI ${state.aiScore}",
                    color = Color.White,
                    fontSize = 17.sp,
                    modifier = Modifier.padding(10.dp)
                )
                Text(state.statusMessage, color = Color.LightGray)
                Spacer(modifier = Modifier.height(14.dp))
                Button(onClick = replay, modifier = Modifier.fillMaxWidth()) { Text("PLAY AGAIN") }
                Button(
                    onClick = back,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151))
                ) { Text("MAIN MENU") }
            }
        }
    }
}
