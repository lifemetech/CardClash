package com.royalcardclash.game.ui.screens

import android.app.Activity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.royalcardclash.game.R
import com.royalcardclash.game.model.PlayerStats

@Composable fun HomeScreen(stats:PlayerStats,onPlayClick:()->Unit,onStatsClick:()->Unit,onHowToPlayClick:()->Unit,onSettingsClick:()->Unit,onAboutClick:()->Unit,onGetCoinsClick:(Activity?)->Unit){
 val activity = LocalContext.current as? Activity
 Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF030712),Color(0xFF172554),Color(0xFF111827)))).padding(20.dp)){Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.SpaceBetween){
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("🪙 ${stats.totalCoins}",color=Color(0xFFFFD54F),fontWeight=FontWeight.Bold,modifier=Modifier.background(Color(0xFF111827),RoundedCornerShape(20.dp)).padding(horizontal=14.dp,vertical=7.dp));OutlinedButton({onGetCoinsClick(activity)},shape=RoundedCornerShape(20.dp)){Text("+ FREE COINS",fontSize=11.sp)}}
  Column(horizontalAlignment=Alignment.CenterHorizontally){Image(painterResource(R.drawable.card_clash_logo),null,Modifier.size(120.dp));Text("CARD CLASH",color=Color(0xFFFFD54F),fontWeight=FontWeight.Black,fontSize=34.sp,letterSpacing=2.sp);Text("STRATEGY EDITION",color=Color.White,fontWeight=FontWeight.Bold,fontSize=13.sp,letterSpacing=4.sp);Text("Think • Predict • Dominate",color=Color(0xFF93C5FD),fontSize=13.sp,modifier=Modifier.padding(top=5.dp))}
  Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){Button(onPlayClick,Modifier.fillMaxWidth().height(58.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFF59E0B)),shape=RoundedCornerShape(29.dp)){Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(8.dp));Text("PLAY STRATEGY DUEL",fontWeight=FontWeight.Black,fontSize=17.sp)};Button(onStatsClick,Modifier.fillMaxWidth().height(50.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF1D4ED8)),shape=RoundedCornerShape(25.dp)){Icon(Icons.Default.EmojiEvents,null);Spacer(Modifier.width(7.dp));Text("STATISTICS")};Button(onHowToPlayClick,Modifier.fillMaxWidth().height(50.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF047857)),shape=RoundedCornerShape(25.dp)){Icon(Icons.Default.Info,null);Spacer(Modifier.width(7.dp));Text("HOW TO PLAY")};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onSettingsClick,Modifier.weight(1f).height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF374151)),shape=RoundedCornerShape(24.dp)){Text("SETTINGS")};Button(onAboutClick,Modifier.weight(1f).height(48.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF374151)),shape=RoundedCornerShape(24.dp)){Text("ABOUT")}}}
  Row(Modifier.fillMaxWidth().background(Color(0xFF111827),RoundedCornerShape(14.dp)).padding(12.dp),horizontalArrangement=Arrangement.SpaceAround){Item("WINS","${stats.gamesWon}");Item("WIN RATE","${stats.winRate.toInt()}%");Item("STREAK","${stats.bestStreak}")}
 }}
}
@Composable private fun Item(a:String,b:String){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(b,color=Color(0xFFFFD54F),fontWeight=FontWeight.Bold,fontSize=17.sp);Text(a,color=Color.LightGray,fontSize=10.sp)}}
