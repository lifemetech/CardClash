package com.royalcardclash.game.engine

import com.royalcardclash.game.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class GameState(
    val playerDeck: List<PlayingCardModel> = emptyList(),
    val aiDeck: List<PlayingCardModel> = emptyList(),
    val playerWonCards: List<PlayingCardModel> = emptyList(),
    val aiWonCards: List<PlayingCardModel> = emptyList(),
    val currentBattlePlayerCard: PlayingCardModel? = null,
    val currentBattleAiCard: PlayingCardModel? = null,
    val previewCard: PlayingCardModel? = null,
    val warPile: List<PlayingCardModel> = emptyList(),
    val playerScore: Int = 26,
    val aiScore: Int = 26,
    val roundsPlayed: Int = 0,
    val phase: GamePhase = GamePhase.IDLE,
    val lastBattleResult: BattleResult? = null,
    val statusMessage: String = "Choose your move. Don't just tap — outplay the AI.",
    val isWarActive: Boolean = false,
    val isPaused: Boolean = false,
    val energy: Int = 5,
    val maxEnergy: Int = 5,
    val scoutCharges: Int = 2,
    val powerCharges: Int = 2,
    val shieldCharges: Int = 2,
    val swapCharges: Int = 2,
    val powerArmed: Boolean = false,
    val shieldArmed: Boolean = false,
    val aiPowerUsed: Boolean = false,
    val aiShieldUsed: Boolean = false
)

class GameEngine {
    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    fun startNewGame() {
        val deck = buildList {
            for (suit in Suit.entries) for (rank in Rank.entries) add(PlayingCardModel(suit = suit, rank = rank))
        }.shuffled()
        _gameState.value = GameState(
            playerDeck = deck.take(26), aiDeck = deck.drop(26),
            playerScore = 26, aiScore = 26, phase = GamePhase.READY_TO_BATTLE,
            statusMessage = "Your turn. Scout, Power, Shield or Swap — then BATTLE."
        )
    }

    fun useTool(tool: StrategyTool): Boolean {
        val s = _gameState.value
        if (s.phase != GamePhase.READY_TO_BATTLE || s.isPaused || s.isWarActive) return false
        return when (tool) {
            StrategyTool.SCOUT -> if (s.scoutCharges > 0 && s.energy >= 1 && s.playerDeck.isNotEmpty()) {
                _gameState.update { it.copy(previewCard = it.playerDeck.first().copy(isFaceUp = true), energy = it.energy - 1, scoutCharges = it.scoutCharges - 1, statusMessage = "Scout revealed your next card. Now decide whether to Power or save it.") }; true
            } else false
            StrategyTool.POWER -> if (s.powerCharges > 0 && s.energy >= 2) {
                _gameState.update { it.copy(powerArmed = true, energy = it.energy - 2, powerCharges = it.powerCharges - 1, statusMessage = "⚡ POWER armed: your next card gets +3 strength.") }; true
            } else false
            StrategyTool.SHIELD -> if (s.shieldCharges > 0 && s.energy >= 2) {
                _gameState.update { it.copy(shieldArmed = true, energy = it.energy - 2, shieldCharges = it.shieldCharges - 1, statusMessage = "🛡️ SHIELD armed: it can block your next loss.") }; true
            } else false
            StrategyTool.SWAP -> if (s.swapCharges > 0 && s.energy >= 3 && s.playerDeck.size >= 2) {
                val d = s.playerDeck.toMutableList(); val first = d.removeAt(0); d.add(1, first)
                _gameState.update { it.copy(playerDeck = d, energy = it.energy - 3, swapCharges = it.swapCharges - 1, previewCard = null, statusMessage = "🔄 SWAP used: your second card is now on top.") }; true
            } else false
        }
    }

    fun playBattleRound(): Pair<BattleResult, Int> {
        val s = _gameState.value
        if (s.phase == GamePhase.GAME_OVER || s.isPaused || s.phase == GamePhase.BATTLE_ANIMATING) return Pair(s.lastBattleResult ?: BattleResult.WAR_TIE, 0)
        var pDeck = s.playerDeck.toMutableList(); var aDeck = s.aiDeck.toMutableList()
        var pWon = s.playerWonCards.toMutableList(); var aWon = s.aiWonCards.toMutableList()
        val pile = s.warPile.toMutableList()
        replenish(pDeck, pWon); replenish(aDeck, aWon)
        if (pDeck.isEmpty()) return end(false, "AI wins — you ran out of cards!", pDeck, aDeck, pWon, aWon, 0)
        if (aDeck.isEmpty()) return end(true, "VICTORY — AI ran out of cards!", pDeck, aDeck, pWon, aWon, 0)

        val pc = pDeck.removeAt(0).copy(isFaceUp = true); val ac = aDeck.removeAt(0).copy(isFaceUp = true)
        pile += pc; pile += ac
        val aiPower = !s.aiPowerUsed && ac.rank.value >= 12 && aDeck.size > 4
        val aiShield = !s.aiShieldUsed && ac.rank.value <= 8 && aDeck.size < 18
        val pStrength = if (s.powerArmed) minOf(14, pc.rank.value + 3) else pc.rank.value
        val aStrength = if (aiPower) minOf(14, ac.rank.value + 2) else ac.rank.value
        val newEnergy = minOf(s.maxEnergy, s.energy + 1)
        val aiPowerUsed = s.aiPowerUsed || aiPower
        val aiShieldUsed = s.aiShieldUsed || aiShield

        if (pStrength == aStrength) {
            replenish(pDeck, pWon); replenish(aDeck, aWon)
            if (pDeck.size < 4 || aDeck.size < 4) {
                val playerWins = pDeck.size >= 4
                return end(playerWins, if (playerWins) "AI cannot complete the War. You win!" else "You cannot complete the War. AI wins!", pDeck, aDeck, pWon, aWon, pile.size)
            }
            repeat(3) { pile += pDeck.removeAt(0).copy(isFaceUp = false); pile += aDeck.removeAt(0).copy(isFaceUp = false) }
            _gameState.update { it.copy(playerDeck=pDeck, aiDeck=aDeck, playerWonCards=pWon, aiWonCards=aWon, currentBattlePlayerCard=pc, currentBattleAiCard=ac, previewCard=null, warPile=pile, playerScore=pDeck.size+pWon.size, aiScore=aDeck.size+aWon.size, roundsPlayed=s.roundsPlayed+1, phase=GamePhase.WAR_DECLARED, lastBattleResult=BattleResult.WAR_TIE, isWarActive=true, energy=newEnergy, powerArmed=false, shieldArmed=false, aiPowerUsed=aiPowerUsed, aiShieldUsed=aiShieldUsed, statusMessage="⚔️ WAR! Three cards are down. Tap FIGHT WAR to reveal the deciding card." ) }
            return Pair(BattleResult.WAR_TIE, pile.size)
        }

        val playerWins = pStrength > aStrength
        if (!playerWins && s.shieldArmed) {
            pDeck.add(pc.copy(isFaceUp=false)); aDeck.add(ac.copy(isFaceUp=false));
            _gameState.update { it.copy(playerDeck=pDeck, aiDeck=aDeck, playerWonCards=pWon, aiWonCards=aWon, currentBattlePlayerCard=pc, currentBattleAiCard=ac, previewCard=null, warPile=emptyList(), playerScore=pDeck.size+pWon.size, aiScore=aDeck.size+aWon.size, roundsPlayed=s.roundsPlayed+1, phase=GamePhase.READY_TO_BATTLE, lastBattleResult=BattleResult.SHIELD_BLOCKED, shieldArmed=false, powerArmed=false, energy=newEnergy, aiPowerUsed=aiPowerUsed, aiShieldUsed=aiShieldUsed, statusMessage="🛡️ SHIELD BLOCKED the loss! Both cards return to the deck." ) }
            return Pair(BattleResult.SHIELD_BLOCKED, 0)
        }

        if (playerWins) pWon.addAll(pile) else aWon.addAll(pile)
        val ps=pDeck.size+pWon.size; val ascore=aDeck.size+aWon.size
        if (ps >= 52 || ascore >= 52) return end(ps >= 52, if (ps >= 52) "🏆 PERFECT VICTORY — all 52 cards are yours!" else "DEFEAT — AI captured the full deck.", pDeck, aDeck, pWon, aWon, pile.size)
        _gameState.update { it.copy(playerDeck=pDeck, aiDeck=aDeck, playerWonCards=pWon, aiWonCards=aWon, currentBattlePlayerCard=pc, currentBattleAiCard=ac, previewCard=null, warPile=emptyList(), playerScore=ps, aiScore=ascore, roundsPlayed=s.roundsPlayed+1, phase=GamePhase.READY_TO_BATTLE, lastBattleResult=if(playerWins) BattleResult.PLAYER_WIN else BattleResult.AI_WIN, energy=newEnergy, powerArmed=false, shieldArmed=false, aiPowerUsed=aiPowerUsed, aiShieldUsed=aiShieldUsed, statusMessage=if(playerWins) "🔥 You won! Captured ${pile.size} cards." else "🤖 AI won this battle. Think ahead for the next one." ) }
        return Pair(if(playerWins) BattleResult.PLAYER_WIN else BattleResult.AI_WIN, pile.size)
    }

    fun resolveWar(): Pair<BattleResult, Int> {
        val s=_gameState.value; if(!s.isWarActive || s.phase==GamePhase.GAME_OVER) return Pair(BattleResult.WAR_TIE,0)
        var pDeck=s.playerDeck.toMutableList(); var aDeck=s.aiDeck.toMutableList(); var pWon=s.playerWonCards.toMutableList(); var aWon=s.aiWonCards.toMutableList(); val pile=s.warPile.toMutableList()
        replenish(pDeck,pWon); replenish(aDeck,aWon)
        if(pDeck.isEmpty() || aDeck.isEmpty()) return end(pDeck.isNotEmpty(), "War cannot continue.", pDeck,aDeck,pWon,aWon,pile.size)
        if(pDeck.size<1 || aDeck.size<1) return end(pDeck.size>=1,"War cannot continue.",pDeck,aDeck,pWon,aWon,pile.size)
        val pc=pDeck.removeAt(0).copy(isFaceUp=true); val ac=aDeck.removeAt(0).copy(isFaceUp=true); pile+=pc; pile+=ac
        val p=pc.rank.value; val a=ac.rank.value
        if(p==a){
            replenish(pDeck,pWon); replenish(aDeck,aWon)
            if(pDeck.size<4 || aDeck.size<4) return end(pDeck.size>=4,"Final War decides the match!",pDeck,aDeck,pWon,aWon,pile.size)
            repeat(3){pile+=pDeck.removeAt(0).copy(isFaceUp=false); pile+=aDeck.removeAt(0).copy(isFaceUp=false)}
            _gameState.update{it.copy(playerDeck=pDeck,aiDeck=aDeck,playerWonCards=pWon,aiWonCards=aWon,currentBattlePlayerCard=pc,currentBattleAiCard=ac,warPile=pile,playerScore=pDeck.size+pWon.size,aiScore=aDeck.size+aWon.size,phase=GamePhase.WAR_DECLARED,isWarActive=true,lastBattleResult=BattleResult.WAR_TIE,statusMessage="⚔️ Another WAR! Same rank — stay calm and fight again.")}
            return Pair(BattleResult.WAR_TIE,pile.size)
        }
        val playerWins=p>a; if(playerWins)pWon.addAll(pile) else aWon.addAll(pile); val ps=pDeck.size+pWon.size; val ascore=aDeck.size+aWon.size
        if(ps>=52||ascore>=52)return end(ps>=52,if(ps>=52)"🏆 You conquered the deck!" else "AI captured all 52 cards.",pDeck,aDeck,pWon,aWon,pile.size)
        _gameState.update{it.copy(playerDeck=pDeck,aiDeck=aDeck,playerWonCards=pWon,aiWonCards=aWon,currentBattlePlayerCard=pc,currentBattleAiCard=ac,warPile=emptyList(),playerScore=ps,aiScore=ascore,phase=GamePhase.READY_TO_BATTLE,isWarActive=false,lastBattleResult=if(playerWins)BattleResult.PLAYER_WIN else BattleResult.AI_WIN,energy=minOf(s.maxEnergy,s.energy+1),statusMessage=if(playerWins)"⚔️ War won! You captured ${pile.size} cards." else "⚔️ AI won the War. Next decision matters.") }
        return Pair(if(playerWins)BattleResult.PLAYER_WIN else BattleResult.AI_WIN,pile.size)
    }

    private fun replenish(deck:MutableList<PlayingCardModel>,won:MutableList<PlayingCardModel>){if(deck.isEmpty()&&won.isNotEmpty()){deck.addAll(won.shuffled().map{it.copy(isFaceUp=false)});won.clear()}}
    private fun end(playerWon:Boolean,message:String,pDeck:MutableList<PlayingCardModel>,aDeck:MutableList<PlayingCardModel>,pWon:MutableList<PlayingCardModel>,aWon:MutableList<PlayingCardModel>,cards:Int):Pair<BattleResult,Int>{
        val ps=if(playerWon)52 else pDeck.size+pWon.size; val ascore=if(playerWon)0 else aDeck.size+aWon.size
        _gameState.update{it.copy(playerDeck=pDeck,aiDeck=aDeck,playerWonCards=pWon,aiWonCards=aWon,playerScore=ps,aiScore=ascore,phase=GamePhase.GAME_OVER,isWarActive=false,lastBattleResult=if(playerWon)BattleResult.PLAYER_WIN else BattleResult.AI_WIN,warPile=emptyList(),statusMessage=message,powerArmed=false,shieldArmed=false,previewCard=null)}
        return Pair(if(playerWon)BattleResult.PLAYER_WIN else BattleResult.AI_WIN,cards)
    }
    fun togglePause(paused:Boolean){_gameState.update{it.copy(isPaused=paused)}}
}
