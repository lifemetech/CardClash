package com.royalcardclash.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.royalcardclash.game.ui.components.PlayingCardView
import com.royalcardclash.game.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    viewModel: GameViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showPauseDialog by remember { mutableStateOf(false) }
    var showRulesDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF1A1C29), Color(0xFF0F1015))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Back, Score/Energy, Pause/Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ENERGY: ${uiState.energy}",
                        color = Color(0xFFFFD700),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "WAR STREAK: ${uiState.warStreak}",
                        color = Color(0xFFFF4500),
                        fontSize = 12.sp
                    )
                }

                Row {
                    IconButton(onClick = { showRulesDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Rules",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = { showPauseDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Pause",
                            tint = Color.White
                        )
                    }
                }
            }

            // Opponent Area (AI)
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "OPPONENT (${uiState.aiScore} pts)",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .size(120.dp, 160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2C3E50))
                        .border(2.dp, Color(0xFF34495E), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (uiState.aiCard != null) {
                        PlayingCardView(card = uiState.aiCard!!)
                    } else {
                        Text(
                            text = "Card Back",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Hand: ${uiState.aiHandCount}",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }

            // Battle Status / War Notification
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (uiState.isWarActive) {
                        Text(
                            text = "⚔️ WAR! CARDS TIED! ⚔️",
                            color = Color.Red,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Stakes tripled. Draw again!",
                            color = Color.Yellow,
                            fontSize = 12.sp
                        )
                    } else {
                        Text(
                            text = uiState.battleStatusMessage.ifEmpty { "Tap a card to battle!" },
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Player Area
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "PLAYER (${uiState.playerScore} pts)",
                    color = Color.LightGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .size(120.dp, 160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF34495E))
                        .border(2.dp, Color(0xFF1ABC9C), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (uiState.playerCard != null) {
                        PlayingCardView(card = uiState.playerCard!!)
                    } else {
                        Text(
                            text = "Your Play",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Strategy Tools Toolbar (Scout, Power, Shield, Swap)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ToolButton(
                    title = "Scout",
                    cost = 1,
                    enabled = uiState.energy >= 1,
                    onClick = { viewModel.useScoutTool() }
                )
                ToolButton(
                    title = "Power",
                    cost = 2,
                    enabled = uiState.energy >= 2,
                    onClick = { viewModel.usePowerTool() }
                )
                ToolButton(
                    title = "Shield",
                    cost = 2,
                    enabled = uiState.energy >= 2,
                    onClick = { viewModel.useShieldTool() }
                )
                ToolButton(
                    title = "Swap",
                    cost = 3,
                    enabled = uiState.energy >= 3,
                    onClick = { viewModel.useSwapTool() }
                )
            }

            // Action / Draw Button
            Button(
                onClick = { viewModel.drawAndBattle() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27AE60)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (uiState.isGameOver) "Restart Game" else "Draw & Battle",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        // Pause Dialog
        if (showPauseDialog) {
            AlertDialog(
                onDismissRequest = { showPauseDialog = false },
                title = { Text("Game Paused") },
                text = { Text("Choose your action:") },
                confirmButton = {
                    TextButton(onClick = {
                        showPauseDialog = false
                        viewModel.resetGame()
                    }) {
                        Text("Restart")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showPauseDialog = false }) {
                        Text("Resume")
                    }
                }
            )
        }

        // Rules Dialog
        if (showRulesDialog) {
            AlertDialog(
                onDismissRequest = { showRulesDialog = false },
                title = { Text("Card Clash: Strategy Edition Rules") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("• Higher card wins the battle.")
                        Text("• Ties trigger a WAR with tripled stakes!")
                        Text("• Use Scout (1 Energy) to preview AI card.")
                        Text("• Use Power (2 Energy) to boost your card.")
                        Text("• Use Shield (2 Energy) to protect against loss.")
                        Text("• Use Swap (3 Energy) to exchange your card.")
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showRulesDialog = false }) {
                        Text("Got it")
                    }
                }
            )
        }

        // Game Over Overlay
        if (uiState.isGameOver) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xEE000000)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = if (uiState.playerScore > uiState.aiScore) "VICTORY! 🎉" else "DEFEAT! 💀",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Final Score - You: ${uiState.playerScore} | AI: ${uiState.aiScore}",
                        color = Color.LightGray,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.resetGame() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27AE60))
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Play Again")
                    }
                }
            }
        }
    }
}

private fun RowScope.ToolButton(
    title: String,
    cost: Int,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .weight(1f)
            .height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF34495E),
            disabledContainerColor = Color(0xFF1C2833)
        ),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(4.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                color = if (enabled) Color.White else Color.Gray,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "$cost NRG",
                color = if (enabled) Color(0xFFFFD700) else Color.DarkGray,
                fontSize = 10.sp
            )
        }
    }
}