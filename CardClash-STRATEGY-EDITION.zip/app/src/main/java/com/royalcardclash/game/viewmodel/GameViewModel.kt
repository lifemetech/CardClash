package com.royalcardclash.game.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.royalcardclash.game.ads.AdManager
import com.royalcardclash.game.audio.SoundManager
import com.royalcardclash.game.data.PreferencesManager
import com.royalcardclash.game.engine.GameEngine
import com.royalcardclash.game.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs=PreferencesManager(application)
    val soundManager=SoundManager(application); val adManager=AdManager(application); val engine=GameEngine()
    val gameState=engine.gameState
    val playerStats:StateFlow<PlayerStats>=prefs.playerStats.stateIn(viewModelScope,SharingStarted.Lazily,PlayerStats())
    val isSoundEnabled=prefs.isSoundEnabled.stateIn(viewModelScope,SharingStarted.Lazily,true)
    val isVibrationEnabled=prefs.isVibrationEnabled.stateIn(viewModelScope,SharingStarted.Lazily,true)
    private var animating=false
    init{viewModelScope.launch{combine(isSoundEnabled,isVibrationEnabled){a,b->a to b}.collect{(a,b)->soundManager.updateSettings(a,b)}}}
    fun startNewGame(){soundManager.playClick();engine.startNewGame()}
    fun useTool(tool:StrategyTool){if(engine.useTool(tool))soundManager.playClick()}
    fun executeBattleRound(){if(animating)return;animating=true;soundManager.playCardFlip();viewModelScope.launch{val(r,_)=if(gameState.value.isWarActive)engine.resolveWar() else engine.playBattleRound();when(r){BattleResult.PLAYER_WIN->soundManager.playWin();BattleResult.AI_WIN->soundManager.playLose();BattleResult.WAR_TIE->soundManager.playClick();BattleResult.SHIELD_BLOCKED->soundManager.playClick()};delay(350);animating=false;if(gameState.value.phase==GamePhase.GAME_OVER)onGameOver()}}
    fun setPauseState(p:Boolean){engine.togglePause(p)}
    private fun onGameOver(){val s=gameState.value;val win=s.playerScore>s.aiScore;viewModelScope.launch{prefs.recordMatchResult(win,s.playerScore,if(win)50 else 10)}}
    fun claimRewardedAdCoins(activity:Activity?,onSuccess:()->Unit,onFailure:()->Unit){if(activity!=null)adManager.showRewardedAd(activity,{viewModelScope.launch{prefs.addCoins(100);soundManager.playCoinReward();onSuccess()}},onFailure) else viewModelScope.launch{prefs.addCoins(100);soundManager.playCoinReward();onSuccess()}}
    fun toggleSound(v:Boolean){viewModelScope.launch{prefs.setSoundEnabled(v)}}
    fun toggleVibration(v:Boolean){viewModelScope.launch{prefs.setVibrationEnabled(v)}}
    override fun onCleared(){soundManager.release();super.onCleared()}
}
