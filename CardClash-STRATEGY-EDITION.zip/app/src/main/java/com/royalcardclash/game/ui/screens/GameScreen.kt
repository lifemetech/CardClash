package com.royalcardclash.game.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.royalcardclash.game.model.*
import com.royalcardclash.game.ui.components.PlayingCardView
import com.royalcardclash.game.viewmodel.GameViewModel

@Composable
fun GameScreen(viewModel:GameViewModel,onBackToHome:()->Unit){
 val s by viewModel.gameState.collectAsState()
 Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071E1A),Color(0xFF020B0A)))).padding(12.dp)){
  Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally){
   Row(Modifier.fillMaxWidth().background(Color(0xFF0B3D34),RoundedCornerShape(16.dp)).border(1.dp,Color(0xFFFFD54F),RoundedCornerShape(16.dp)).padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
    Score("AI",s.aiScore,Color(0xFFFF8A9B)); Column(horizontalAlignment=Alignment.CenterHorizontally){Text("ROUND ${s.roundsPlayed}",color=Color(0xFFFFD54F),fontWeight=FontWeight.Black);Text("ENERGY ${s.energy}/${s.maxEnergy}",color=Color(0xFF7DD3FC),fontSize=11.sp)}; Score("YOU",s.playerScore,Color(0xFF6EE7B7)); IconButton({viewModel.setPauseState(true)}){Icon(Icons.Default.Pause,null,tint=Color.White)}}
   Spacer(Modifier.height(8.dp));
   Row(horizontalArrangement=Arrangement.spacedBy(20.dp),verticalAlignment=Alignment.CenterVertically){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("AI DECK",color=Color.LightGray,fontSize=11.sp);PlayingCardView(PlayingCardModel(suit=Suit.SPADES,rank=Rank.ACE),52.dp,76.dp)};Text("VS",color=Color(0xFFFFD54F),fontWeight=FontWeight.Black);Column(horizontalAlignment=Alignment.CenterHorizontally){Text("YOUR DECK",color=Color.LightGray,fontSize=11.sp);PlayingCardView(PlayingCardModel(suit=Suit.HEARTS,rank=Rank.ACE),52.dp,76.dp)}}
   Spacer(Modifier.height(8.dp));
   Card(Modifier.fillMaxWidth().weight(1f),colors=CardDefaults.cardColors(containerColor=Color(0xFF0A4F43)),shape=RoundedCornerShape(20.dp)){Column(Modifier.fillMaxSize().padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.SpaceBetween){
    Column(horizontalAlignment=Alignment.CenterHorizontally){Text("STRATEGY TABLE",color=Color(0xFFFFD54F),fontWeight=FontWeight.Bold,fontSize=12.sp);Text(s.statusMessage,color=Color.White,fontSize=14.sp,fontWeight=FontWeight.Medium,modifier=Modifier.padding(vertical=7.dp))}
    if(s.previewCard!=null && s.phase==GamePhase.READY_TO_BATTLE){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("SCOUTED NEXT CARD",color=Color(0xFF7DD3FC),fontSize=10.sp);PlayingCardView(s.previewCard!!,60.dp,86.dp)}}
    Row(horizontalArrangement=Arrangement.spacedBy(18.dp),verticalAlignment=Alignment.CenterVertically){s.currentBattlePlayerCard?.let{Column(horizontalAlignment=Alignment.CenterHorizontally){Text("YOU",color=Color.LightGray,fontSize=10.sp);PlayingCardView(it,72.dp,104.dp)}};if(s.currentBattlePlayerCard!=null&&s.currentBattleAiCard!=null)Text(if(s.isWarActive)"⚔️ WAR":"VS",color=Color(0xFFFFD54F),fontSize=20.sp,fontWeight=FontWeight.Black);s.currentBattleAiCard?.let{Column(horizontalAlignment=Alignment.CenterHorizontally){Text("AI",color=Color.LightGray,fontSize=10.sp);PlayingCardView(it,72.dp,104.dp)}}}
    if(s.isWarActive) Text("Battle pile: ${s.warPile.size} cards",color=Color(0xFFFFD54F),fontSize=12.sp)
   }}
   Spacer(Modifier.height(8.dp));
   Text("YOUR TOOLS",color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp);
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){ToolButton("👁 SCOUT","${s.scoutCharges}",Color(0xFF2563EB),s.energy>=1&&s.scoutCharges>0&&!s.isWarActive){viewModel.useTool(StrategyTool.SCOUT)};ToolButton("⚡ POWER","${s.powerCharges}",Color(0xFFD97706),Color(0xFFFFD54F),s.energy>=2&&s.powerCharges>0&&!s.isWarActive){viewModel.useTool(StrategyTool.POWER)};ToolButton("🛡 SHIELD","${s.shieldCharges}",Color(0xFF059669),s.energy>=2&&s.shieldCharges>0&&!s.isWarActive){viewModel.useTool(StrategyTool.SHIELD)};ToolButton("🔄 SWAP","${s.swapCharges}",Color(0xFF7C3AED),s.energy>=3&&s.swapCharges>0&&!s.isWarActive){viewModel.useTool(StrategyTool.SWAP)}}
   Spacer(Modifier.height(8.dp));
   Button({viewModel.executeBattleRound()},Modifier.fillMaxWidth().height(54.dp),enabled=s.phase!=GamePhase.GAME_OVER,colors=ButtonDefaults.buttonColors(containerColor=if(s.isWarActive)Color(0xFFE11D48) else Color(0xFFF59E0B)),shape=RoundedCornerShape(27.dp)){Text(if(s.isWarActive)"⚔️ FIGHT WAR" else "🃏 BATTLE NOW",fontWeight=FontWeight.Black,fontSize=16.sp,color=Color.White)}
   Spacer(Modifier.height(4.dp));Text("Cards remaining: You ${s.playerScore} • AI ${s.aiScore}",color=Color.LightGray,fontSize=11.sp)
  }
  if(s.isPaused)OverlayPause(viewModel,onBackToHome)
  if(s.phase==GamePhase.GAME_OVER)OverlayResult(s,onBackToHome){viewModel.startNewGame()}
 }}

@Composable private fun Score(label:String,value:Int,color:Color){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(label,color=Color.LightGray,fontSize=11.sp);Text("$value",color=color,fontWeight=FontWeight.Black,fontSize=20.sp)}}
@Composable private fun ToolButton(title:String,count:String,color:Color,enabled:Boolean,onClick:()->Unit){Button(onClick,Modifier.weight(1f).height(58.dp),enabled=enabled,contentPadding=PaddingValues(2.dp),colors=ButtonDefaults.buttonColors(containerColor=color,disabledContainerColor=Color(0xFF334155)),shape=RoundedCornerShape(12.dp)){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(title,fontSize=10.sp,fontWeight=FontWeight.Bold);Text("$count left",fontSize=9.sp)}}}
@Composable private fun ToolButton(title:String,count:String,color:Color,accent:Color,enabled:Boolean,onClick:()->Unit)=ToolButton(title,count,color,enabled,onClick)
@Composable private fun OverlayPause(vm:GameViewModel,back:()->Unit){Box(Modifier.fillMaxSize().background(Color.Black.copy(.82f)),contentAlignment=Alignment.Center){Card(Modifier.fillMaxWidth(.86f),colors=CardDefaults.cardColors(containerColor=Color(0xFF111827)),shape=RoundedCornerShape(22.dp)){Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){Text("GAME PAUSED",color=Color(0xFFFFD54F),fontWeight=FontWeight.Black,fontSize=24.sp);Button({vm.setPauseState(false)},Modifier.fillMaxWidth()){Text("RESUME")};Button({vm.setPauseState(false);back()},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF374151))){Text("MAIN MENU")}}}}}
@Composable private fun OverlayResult(s:com.royalcardclash.game.engine.GameState,back:()->Unit,replay:()->Unit){Box(Modifier.fillMaxSize().background(Color.Black.copy(.86f)),contentAlignment=Alignment.Center){Card(Modifier.fillMaxWidth(.88f),colors=CardDefaults.cardColors(containerColor=Color(0xFF111827)),shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){val win=s.playerScore>s.aiScore;Text(if(win)"🏆 VICTORY" else "DEFEAT",color=if(win)Color(0xFFFFD54F) else Color(0xFFFB7185),fontWeight=FontWeight.Black,fontSize=30.sp);Text("You ${s.playerScore}  •  AI ${s.aiScore}",color=Color.White,fontSize=17.sp,modifier=Modifier.padding(10.dp));Text(s.statusMessage,color=Color.LightGray);Spacer(Modifier.height(14.dp));Button(replay,Modifier.fillMaxWidth()){Text("PLAY AGAIN")};Button(back,Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF374151))){Text("MAIN MENU")}}}}}
